from tkinter import *
import socket, threading, pickle, sqlite3

HEADER = 64
PORT = 8080
SERVER = socket.gethostbyname(socket.gethostname())
ADDR = (SERVER, PORT)
FORMAT = 'utf-8'

server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
server.bind(ADDR)

root = Tk()

root.title("Phalanx")
root.geometry("504x600")
root.iconbitmap("icon.ico")
root.resizable(width=False, height=False)
root.configure(bg="black")

def all_children(window):
    _list = window.winfo_children()

    for item in _list:
        if item.winfo_children():
            _list.extend(item.winfo_children())

    return _list


def clear_window():
    widget_list = all_children(root)
    for item in widget_list:
        item.grid_forget()


def warning(msg):

    window = Tk()
    window.title("Phalanx")
    window.geometry("320x100")
    window.iconbitmap("icon.ico")
    window.resizable(width=False, height=False)
    window.configure(bg="black")

    msgLabel =Label(window, text=msg)
    msgLabel.configure(bg='black', fg='white', font=("Courier", 14))
    msgLabel.pack(pady=5)

    btn = Button(window, text="OK", command=lambda: window.destroy())
    btn.configure(bg='black', fg='white', font=("Courier", 14))
    btn.pack(pady=5)


uList = Listbox(root, width=17, height=10)
uList.grid(row=1, column=0, columnspan=2, sticky='w')
uList.configure(bg='black', fg='white', font=("Courier", 12))
scrollbar = Scrollbar(root)
scrollbar.grid(row=1, column=1, sticky='ns')

# populate userList

uList.config(yscrollcommand=scrollbar.set)
scrollbar.config(command=uList.yview)
uList.yview(END)

eLog = Listbox(root, width=48, height=21)
eLog.grid(row=2, column=0, columnspan=4)
eLog.configure(bg='black', fg='white', font=("Courier", 12))
scrollbar = Scrollbar(root)
scrollbar.grid(row=2, column=5, sticky='ns')

eLog.config(yscrollcommand=scrollbar.set)
scrollbar.config(command=eLog.yview)
eLog.yview(END)

def handle_client(conn, addr):
    eLog.insert(END, f" [NEW CONNECTION] {addr} connected.")

    connected = True
    while connected:
        msg_length = conn.recv(HEADER).decode(FORMAT)
        if msg_length:
            msg_length = int(msg_length)
            msg = conn.recv(msg_length).decode(FORMAT)

            print(f"{msg}")

    conn.close()


def start():
    server.listen()
    while True:
        conn, addr = server.accept()
        thread = threading.Thread(target=handle_client(conn, addr))
        thread.start()
        print(f"[ACTIVE CONNECTIONS] {threading.activeCount() - 1}")

root.mainloop()

start()
