from tkinter import *
import socket
from _thread import *

HEADER = 64
PORT = 8080
FORMAT = 'utf-8'
DISCONNECT_MESSAGE = '!DISCONNECT'

root = Tk()

root.title("Phalanx")
root.geometry("504x600")
root.iconbitmap("icon.ico")
root.resizable(width=False, height=False)
root.configure(bg="black")


def clear_window():
    def all_children(window):
        _list = window.winfo_children()

        for child in _list:
            if child.winfo_children():
                _list.extend(child.winfo_children())

        return _list

    widget_list = all_children(root)
    for item in widget_list:
        item.grid_forget()


def connect(name, address):
    if len(name) > 25:
        warning("Name is too long.")
    elif name == "":
        warning("Name is invalid.")
    else:
        try:
            global userName
            userName = name
            chatWindow(address)
        except:
            warning("Unable to connect to server.")


def warning(msg):
    window = Tk()
    window.title("Phalanx")
    window.geometry("320x100")
    window.iconbitmap("icon.ico")
    window.resizable(width=False, height=False)
    window.configure(bg="black")

    msgLabel = Label(window, text=msg)
    msgLabel.configure(bg='black', fg='white', font=("Courier", 14))
    msgLabel.pack(pady=5)

    btn = Button(window, text="OK", command=lambda: window.destroy())
    btn.configure(bg='black', fg='white', font=("Courier", 14))
    btn.pack(pady=5)


def chatWindow(ip):
    clear_window()

    SERVER = ip
    ADDR = (SERVER, PORT)

    client = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    client.connect(ADDR)

    userCount = Label(root, text='[1] Currently Online')
    userCount.configure(bg='black', fg='white', font=("Courier", 12))
    userCount.grid(row=0, column=0, sticky='w')

    disconnectBtn = Button(root, text="DISCONNECT", cursor='hand2', command=lambda: disconnect(client))
    disconnectBtn.grid(row=0, column=1, columnspan=3, sticky='e')
    disconnectBtn.configure(bg='black', fg='white', font=("Courier", 12))

    chatLog = Listbox(root, width=48, height=24)
    chatLog.grid(row=1, column=0, columnspan=3)
    chatLog.configure(bg='black', fg='white', font=("Courier", 12))
    scrollbar = Scrollbar(root)
    scrollbar.grid(row=1, column=3, sticky='ns')

    # populate chatLog

    chatLog.config(yscrollcommand=scrollbar.set)
    scrollbar.config(command=chatLog.yview)
    chatLog.yview(END)

    messageBox = Text(root, width=40, height=4, insertbackground='white')
    messageBox.configure(bg='black', fg='white', font=("Courier", 12))
    messageBox.grid(row=2, column=0, sticky="sw", columnspan=2, pady=15)

    sendBtn = Button(root,
                     image=sendImage,
                     cursor='hand2',
                     command=lambda: start_new_thread(send, (messageBox.get('1.0', 'end')))
                     )
    sendBtn.configure(bg='black', fg='white')
    sendBtn.grid(row=2, column=1, columnspan=3, sticky="e", padx=5)

    def disconnect(client):
        client.close()
        root.destroy()

    def send(uName, msg):
        if (msg == DISCONNECT_MESSAGE):
            client.close()
            root.destroy()
        else:
            msg = uName + ": " + msg
        try:
            msg = f"[{uName}]: {msg}"

            message = msg.encode(FORMAT)
            msg_length = len(message)
            send_length = str(msg_length).encode(FORMAT)
            send_length += b' ' * (HEADER - len(send_length))
            client.send(send_length)
            client.send(message)
            messageBox.delete('1.0', END)
        except:
            warning("Message failed to send")

    while True:
        response = client.recv(HEADER)


menuImage = PhotoImage(file="menuOne.png")
sendImage = PhotoImage(file="sendButton.png")
menuLabel = Label(root, image=menuImage)
menuLabel.grid(row=0, column=0, columnspan=4)

entryLabel = Label(root, text='ENTER NAME: ')
entryLabel.configure(bg='black', fg='white', font=("Courier", 20))
entryLabel.grid(row=1, column=0, pady=40)

nameEntry = Entry(root, width=25, insertbackground='white')
nameEntry.configure(bg='black', fg='white', font=("Courier", 12))
nameEntry.grid(row=1, column=1, pady=40, sticky='w')

addressLabel = Label(root, text='IP ADDRESS: ')
addressLabel.configure(bg='black', fg='white', font=("Courier", 20))
addressLabel.grid(row=2, column=0, pady=40)

addressEntry = Entry(root, width=25, insertbackground='white')
addressEntry.configure(bg='black', fg='white', font=("Courier", 12))
addressEntry.grid(row=2, column=1, pady=40, sticky='w')

connectButton = Button(root,
                       text='Connect To Server',
                       height=2,
                       width=20,
                       cursor='hand2',
                       command=lambda: connect(nameEntry.get(), addressEntry.get())
                       )

connectButton.configure(bg='black', fg='white', font=("Courier", 20))
connectButton.grid(row=3, column=0, pady=18, columnspan=3)

root.mainloop()
